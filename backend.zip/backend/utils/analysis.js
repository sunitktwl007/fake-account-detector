/**
 * Analysis Utilities
 * Core analysis algorithms for fake account detection
 * Developed by Sunit Katuwal (BSc CSIT)
 */

/**
 * Analyze username for suspicious patterns
 * Checks: excessive numbers, random characters, suspicious length, common fake patterns
 */
function analyzeUsername(username, seed) {
    let risk = 20; // Base risk

    // Check for excessive numbers
    const numberCount = (username.match(/\d/g) || []).length;
    const numberRatio = numberCount / username.length;
    if (numberRatio > 0.4) risk += 25;
    else if (numberRatio > 0.2) risk += 10;

    // Check for special characters
    const specialChars = (username.match(/[_.-]/g) || []).length;
    if (specialChars > 3) risk += 15;

    // Check for consecutive numbers
    if (/\d{3,}/.test(username)) risk += 20;

    // Check length (very short or very long is suspicious)
    if (username.length < 3) risk += 15;
    if (username.length > 30) risk += 10;

    // Check for common fake patterns
    if (/^user|^test|^fake|^bot|^bot_|^admin/.test(username.toLowerCase())) {
        risk += 30;
    }

    // Check for all caps
    if (username === username.toUpperCase() && username.length > 3) {
        risk += 10;
    }

    // Ensure risk is between 0 and 100
    return Math.min(100, Math.max(0, risk));
}

/**
 * Calculate risk based on followers to following ratio
 * Legitimate accounts typically have reasonable ratios
 */
function calculateFollowerRatio(followers, following, seed) {
    let risk = 25; // Base risk

    const ratio = followers / Math.max(following, 1);

    // Extremely low ratio (more following than followers)
    if (ratio < 0.1) risk += 35;
    else if (ratio < 0.5) risk += 20;
    else if (ratio < 1) risk += 10;

    // Extremely high ratio (unrealistic follower count)
    if (ratio > 100) risk += 40;
    else if (ratio > 50) risk += 30;
    else if (ratio > 10) risk += 15;

    // Very low absolute followers
    if (followers < 10) risk += 20;
    
    // Very high absolute followers with few posts (possibly bought followers)
    if (followers > 100000 && following > 50000) risk += 15;

    return Math.min(100, Math.max(0, risk));
}

/**
 * Analyze engagement metrics
 * High follower count with low engagement is suspicious
 */
function analyzeEngagement(followers, posts, seed) {
    let risk = 20; // Base risk

    // If no posts, it's suspicious
    if (posts === 0) {
        return 90;
    }

    // Calculate engagement potential
    const avgLikesPerPost = (followers * 0.02) + (Math.random() * followers * 0.03);
    const avgCommentsPerPost = (followers * 0.005) + (Math.random() * followers * 0.01);

    // Very high followers with minimal posts
    if (followers > 10000 && posts < 10) {
        risk += 35;
    }

    // Check for engagement indicators
    if (followers > 1000 && posts < 20) {
        risk += 20;
    }

    // Not enough followers for activity
    if (followers < 50 && posts > 500) {
        risk += 15;
    }

    return Math.min(100, Math.max(0, risk));
}

/**
 * Analyze posting activity patterns
 * Legitimate accounts have consistent posting patterns
 */
function analyzeActivity(posts, seed) {
    let risk = 25; // Base risk

    // Very few posts (inactive or new)
    if (posts < 5) {
        risk += 30;
    } else if (posts < 20) {
        risk += 15;
    }

    // Extremely high post count (might be bot-generated or spam)
    if (posts > 5000) {
        risk += 20;
    } else if (posts > 2000) {
        risk += 10;
    }

    // Simulate posting consistency
    const consistencyVariation = seed % 30;
    if (consistencyVariation < 10) {
        risk += 15; // Irregular posting
    }

    return Math.min(100, Math.max(0, risk));
}

/**
 * Analyze bio and description
 */
function analyzeBio(bio, seed) {
    let risk = 20;

    if (!bio || bio.length === 0) {
        risk += 20;
    }

    // Check for spam-like content
    if (bio && (bio.match(/\$|bitcoin|crypto|free|cash/i) || []).length > 0) {
        risk += 25;
    }

    // Check for excessive links
    if (bio && (bio.match(/http|bit\.ly|tinyurl/i) || []).length > 2) {
        risk += 20;
    }

    // Too short bio
    if (bio && bio.length < 5) {
        risk += 10;
    }

    return Math.min(100, Math.max(0, risk));
}

/**
 * Analyze profile completeness
 */
function analyzeProfileCompleteness(profileData, seed) {
    let risk = 30;
    let completedFields = 0;
    const totalFields = 5; // bio, profile pic, website, phone, email

    if (profileData.bio) completedFields++;
    if (profileData.profilePicture) completedFields++;
    if (profileData.website) completedFields++;
    if (profileData.phone) completedFields++;
    if (profileData.email) completedFields++;

    const completeness = completedFields / totalFields;
    risk = Math.round(30 - (completeness * 25));

    return Math.max(0, risk);
}

/**
 * Calculate hashtag usage patterns
 */
function analyzeHashtagUsage(posts, seed) {
    let risk = 25;

    if (posts < 10) {
        risk += 15;
    }

    // Fake accounts often use excessive hashtags
    const avgHashtagsPerPost = 20 + (seed % 15);
    if (avgHashtagsPerPost > 25) {
        risk += 20;
    } else if (avgHashtagsPerPost > 15) {
        risk += 10;
    }

    return Math.min(100, Math.max(0, risk));
}

/**
 * Check for bot-like behavior
 */
function isBotLike(username, followers, posts, seed) {
    let botScore = 0;

    // Bot-like username patterns
    if (/\d{4,}|_\d|bot|bot_/i.test(username)) {
        botScore += 25;
    }

    // Suspicious follower growth
    if (followers > 100000 && posts < 50) {
        botScore += 20;
    }

    // Specific post intervals (bot-like)
    if (posts > 1000 && posts % 100 === 0) {
        botScore += 15;
    }

    return botScore;
}

module.exports = {
    analyzeUsername,
    calculateFollowerRatio,
    analyzeEngagement,
    analyzeActivity,
    analyzeBio,
    analyzeProfileCompleteness,
    analyzeHashtagUsage,
    isBotLike
};
