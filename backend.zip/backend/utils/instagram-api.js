/**
 * Instagram RapidAPI Integration
 * Fetches real Instagram profile data
 * Developed by Sunit Katuwal (BSc CSIT)
 */

const https = require('https');

// RapidAPI Configuration
const RAPIDAPI_KEY = process.env.RAPIDAPI_KEY || '53d19d3826msh4290ed8297b8692p10108ajsn3eba9a50df66';
const RAPIDAPI_HOST = 'instagram-scraper-api2.p.rapidapi.com';

/**
 * Fetch real Instagram profile data via RapidAPI
 * @param {string} username - Instagram username
 * @returns {Promise<Object>} Profile data
 */
function fetchInstagramProfile(username) {
    return new Promise((resolve, reject) => {
        // If no API key, return simulated data
        if (!RAPIDAPI_KEY) {
            console.log('⚠️  No RapidAPI key found. Using simulated data.');
            resolve(null);
            return;
        }

        const options = {
            hostname: RAPIDAPI_HOST,
            port: 443,
            path: `/user-info?username=${encodeURIComponent(username)}`,
            method: 'GET',
            headers: {
                'x-rapidapi-key': RAPIDAPI_KEY,
                'x-rapidapi-host': RAPIDAPI_HOST,
                'useQueryString': 'true'
            }
        };

        console.log(`📡 Fetching Instagram data for @${username}...`);

        const req = https.request(options, (res) => {
            let data = '';

            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                try {
                    const response = JSON.parse(data);

                    console.log(`API Response Status: ${res.statusCode}`);

                    // Check for API errors
                    if (res.statusCode !== 200 || response.status === 'fail' || !response.data) {
                        console.log(`⚠️  API returned: ${JSON.stringify(response).substring(0, 100)}`);
                        resolve(null);
                        return;
                    }

                    // Extract relevant data
                    const profileData = {
                        username: response.data.username,
                        followers: response.data.follower_count || 0,
                        following: response.data.following_count || 0,
                        posts: response.data.media_count || 0,
                        isVerified: response.data.is_verified || false,
                        isPrivate: response.data.is_private || false,
                        biography: response.data.biography || '',
                        profilePictureUrl: response.data.profile_pic_url || '',
                        externalUrl: response.data.external_url || '',
                        source: 'real-api'
                    };

                    console.log(`✓ Got real data: ${profileData.followers} followers`);
                    resolve(profileData);
                } catch (error) {
                    console.error('Error parsing Instagram API response:', error.message);
                    console.error('Raw response:', data.substring(0, 200));
                    resolve(null);
                }
            });
        });

        req.on('error', (error) => {
            console.error('❌ Instagram API request error:', error.message);
            resolve(null); // Fallback to simulated data on error
        });

        // Set timeout
        req.setTimeout(8000, () => {
            console.warn('⏱️  Instagram API request timeout');
            req.destroy();
            resolve(null);
        });

        req.end();
    });
}

/**
 * Fetch TikTok user data via RapidAPI
 * @param {string} username - TikTok username
 * @returns {Promise<Object>} Profile data
 */
function fetchTikTokProfile(username) {
    return new Promise((resolve, reject) => {
        if (!RAPIDAPI_KEY) {
            resolve(null);
            return;
        }

        const options = {
            hostname: 'tiktok-api6.p.rapidapi.com',
            port: 443,
            path: `/user/info?username=${encodeURIComponent(username)}`,
            method: 'GET',
            headers: {
                'x-rapidapi-key': RAPIDAPI_KEY,
                'x-rapidapi-host': 'tiktok-api6.p.rapidapi.com'
            }
        };

        const req = https.request(options, (res) => {
            let data = '';

            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                try {
                    const response = JSON.parse(data);

                    if (!response.user) {
                        resolve(null);
                        return;
                    }

                    const profileData = {
                        username: response.user.uniqueId,
                        followers: response.user.stats?.followerCount || 0,
                        following: response.user.stats?.followingCount || 0,
                        posts: response.user.stats?.videoCount || 0,
                        isVerified: response.user.verified || false,
                        biography: response.user.signature || '',
                        profilePictureUrl: response.user.avatarLarger || '',
                        source: 'real-api'
                    };

                    resolve(profileData);
                } catch (error) {
                    console.error('Error parsing TikTok API response:', error.message);
                    resolve(null);
                }
            });
        });

        req.on('error', (error) => {
            console.error('TikTok API request error:', error.message);
            resolve(null);
        });

        req.setTimeout(5000, () => {
            req.destroy();
            resolve(null);
        });

        req.end();
    });
}

/**
 * Fetch Twitter/X user data via RapidAPI
 * @param {string} username - Twitter username
 * @returns {Promise<Object>} Profile data
 */
function fetchTwitterProfile(username) {
    return new Promise((resolve, reject) => {
        if (!RAPIDAPI_KEY) {
            resolve(null);
            return;
        }

        const options = {
            hostname: 'twitter-api45.p.rapidapi.com',
            port: 443,
            path: `/search?query=${encodeURIComponent(username)}&type=user`,
            method: 'GET',
            headers: {
                'x-rapidapi-key': RAPIDAPI_KEY,
                'x-rapidapi-host': 'twitter-api45.p.rapidapi.com'
            }
        };

        const req = https.request(options, (res) => {
            let data = '';

            res.on('data', (chunk) => {
                data += chunk;
            });

            res.on('end', () => {
                try {
                    const response = JSON.parse(data);

                    if (!response.users || response.users.length === 0) {
                        resolve(null);
                        return;
                    }

                    const user = response.users[0];
                    const profileData = {
                        username: user.screen_name,
                        followers: user.followers_count || 0,
                        following: user.friends_count || 0,
                        posts: user.statuses_count || 0,
                        isVerified: user.verified || false,
                        biography: user.description || '',
                        profilePictureUrl: user.profile_image_url || '',
                        source: 'real-api'
                    };

                    resolve(profileData);
                } catch (error) {
                    console.error('Error parsing Twitter API response:', error.message);
                    resolve(null);
                }
            });
        });

        req.on('error', (error) => {
            console.error('Twitter API request error:', error.message);
            resolve(null);
        });

        req.setTimeout(5000, () => {
            req.destroy();
            resolve(null);
        });

        req.end();
    });
}

/**
 * Get profile data from appropriate platform API
 * @param {string} username - Username
 * @param {string} platform - Platform (instagram, tiktok, twitter)
 * @returns {Promise<Object>} Profile data or null
 */
async function getProfileData(username, platform) {
    try {
        switch (platform.toLowerCase()) {
            case 'instagram':
                return await fetchInstagramProfile(username);
            case 'tiktok':
                return await fetchTikTokProfile(username);
            case 'twitter':
                return await fetchTwitterProfile(username);
            default:
                return null;
        }
    } catch (error) {
        console.error(`Error fetching ${platform} profile:`, error.message);
        return null;
    }
}

module.exports = {
    getProfileData,
    fetchInstagramProfile,
    fetchTikTokProfile,
    fetchTwitterProfile
};
