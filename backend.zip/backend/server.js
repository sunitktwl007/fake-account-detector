const http = require('http');
const url = require('url');
const { analyzeUsername, calculateFollowerRatio, analyzeEngagement, analyzeActivity } = require('./utils/analysis');
const { getProfileData } = require('./utils/instagram-api');

const PORT = process.env.PORT || 3000;

// Helper function to parse JSON body
function parseBody(req, callback) {
    let body = '';
    req.on('data', chunk => {
        body += chunk.toString();
    });
    req.on('end', () => {
        try {
            const data = body ? JSON.parse(body) : {};
            callback(null, data);
        } catch (e) {
            callback(e, null);
        }
    });
}

// Analysis function
function performAnalysis(username, platform, realProfileData = null) {
    const seed = hashUsername(username);
    
    // Use real data if available, otherwise simulate
    let followers, following, posts, isVerified;
    
    if (realProfileData) {
        followers = realProfileData.followers || 0;
        following = realProfileData.following || 0;
        posts = realProfileData.posts || 0;
        isVerified = realProfileData.isVerified || false;
        console.log(`✓ Using real data: ${followers} followers, ${following} following, ${posts} posts`);
    } else {
        ({ followers, following, posts } = generateUserStats(seed));
        isVerified = platform === 'instagram' && seed % 5 === 0;
        console.log(`✓ Using simulated data for @${username}`);
    }
    
    const usernameRisk = analyzeUsername(username, seed);
    const ratioRisk = calculateFollowerRatio(followers, following, seed);
    const engagementRisk = analyzeEngagement(followers, posts, seed);
    const activityRisk = analyzeActivity(posts, seed);
    
    const engagementRate = generateEngagementRate(seed);
    const activityFrequency = generateActivityFrequency(seed);
    const postConsistency = generatePostConsistency(seed);
    const commentRatio = generateCommentRatio(seed);
    const likeDensity = generateLikeDensity(seed);

    const scores = [
        { value: usernameRisk, weight: 0.25 },
        { value: ratioRisk, weight: 0.25 },
        { value: engagementRisk, weight: 0.25 },
        { value: activityRisk, weight: 0.25 }
    ];

    const fakeScore = Math.round(
        scores.reduce((sum, score) => sum + (score.value * score.weight), 0)
    );

    const factors = [
        {
            name: 'Username Pattern',
            description: usernameRisk > 60 
                ? 'Suspicious characters, numbers, or unusual formatting detected'
                : 'Username appears legitimate',
            risk: usernameRisk,
            icon: usernameRisk > 60 ? '⚠️' : '✓'
        },
        {
            name: 'Follower Ratio',
            description: ratioRisk > 60
                ? `Unusual followers-to-following ratio (${(followers/Math.max(following, 1)).toFixed(2)})`
                : `Normal followers-to-following ratio (${(followers/Math.max(following, 1)).toFixed(2)})`,
            risk: ratioRisk,
            icon: ratioRisk > 60 ? '⚠️' : '✓'
        },
        {
            name: 'Engagement Rate',
            description: engagementRisk > 60
                ? `Low engagement rate (${engagementRate.toFixed(1)}%)`
                : `Healthy engagement rate (${engagementRate.toFixed(1)}%)`,
            risk: engagementRisk,
            icon: engagementRisk > 60 ? '⚠️' : '✓'
        },
        {
            name: 'Activity Pattern',
            description: activityRisk > 60
                ? `Irregular posting pattern detected`
                : `Consistent posting pattern`,
            risk: activityRisk,
            icon: activityRisk > 60 ? '⚠️' : '✓'
        },
        {
            name: 'Account Verification',
            description: isVerified
                ? 'Account is officially verified'
                : 'Account is not officially verified',
            risk: isVerified ? 10 : 30,
            icon: isVerified ? '✓' : '⚠️'
        }
    ];

    return {
        followers,
        following,
        posts,
        isVerified,
        fakeScore,
        engagementRate,
        activityFrequency,
        postConsistency,
        commentRatio,
        likeDensity,
        factors
    };
}

function hashUsername(username) {
    let hash = 0;
    for (let i = 0; i < username.length; i++) {
        const char = username.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    return Math.abs(hash);
}

function generateUserStats(seed) {
    const followers = Math.floor(Math.random() * 450000) + 50;
    const following = Math.floor(Math.random() * 10000) + 50;
    const posts = Math.floor(Math.random() * 1000) + 1;
    return { followers, following, posts };
}

function generateEngagementRate(seed) {
    return Math.max(0.5, Math.min(15, Math.random() * 12 + (seed % 3)));
}

function generateActivityFrequency(seed) {
    return Math.max(5, Math.min(95, Math.random() * 80 + (seed % 20)));
}

function generatePostConsistency(seed) {
    return Math.max(0, Math.min(100, Math.random() * 70 + (seed % 30)));
}

function generateCommentRatio(seed) {
    return Math.max(0, Math.min(100, Math.random() * 50 + (seed % 25)));
}

function generateLikeDensity(seed) {
    return Math.max(10, Math.min(100, Math.random() * 75 + (seed % 25)));
}

// Create HTTP server
const server = http.createServer((req, res) => {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Content-Type', 'application/json');

    // Handle OPTIONS
    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }

    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;

    // Health check
    if (pathname === '/health' && req.method === 'GET') {
        res.writeHead(200);
        res.end(JSON.stringify({
            status: 'OK',
            timestamp: new Date().toISOString(),
            service: 'Fake Account Detector API',
            developer: 'Sunit Katuwal (BSc CSIT)'
        }));
        return;
    }

    // Root endpoint
    if (pathname === '/' && req.method === 'GET') {
        res.writeHead(200);
        res.end(JSON.stringify({
            message: 'Fake Account Detector API',
            version: '1.0.0',
            endpoints: {
                analyze: 'POST /api/analyze',
                health: 'GET /health'
            },
            developer: 'Sunit Katuwal (BSc CSIT)'
        }));
        return;
    }

    // Analyze endpoint
    if (pathname === '/api/analyze' && req.method === 'POST') {
        parseBody(req, async (err, data) => {
            if (err) {
                res.writeHead(400);
                res.end(JSON.stringify({
                    error: 'Invalid JSON',
                    message: 'Request body must be valid JSON'
                }));
                return;
            }

            const { username, platform } = data;

            if (!username || !platform) {
                res.writeHead(400);
                res.end(JSON.stringify({
                    error: 'Missing required fields',
                    message: 'Please provide username and platform'
                }));
                return;
            }

            const validPlatforms = ['instagram', 'tiktok', 'twitter'];
            if (!validPlatforms.includes(platform.toLowerCase())) {
                res.writeHead(400);
                res.end(JSON.stringify({
                    error: 'Invalid platform',
                    message: `Platform must be one of: ${validPlatforms.join(', ')}`
                }));
                return;
            }

            if (username.length < 2 || username.length > 100) {
                res.writeHead(400);
                res.end(JSON.stringify({
                    error: 'Invalid username',
                    message: 'Username must be between 2 and 100 characters'
                }));
                return;
            }

            try {
                // Try to fetch real profile data from RapidAPI
                console.log(`Fetching real profile data for @${username} (${platform})...`);
                const realProfileData = await getProfileData(username, platform);

                const analysisResult = performAnalysis(username, platform, realProfileData);

                res.writeHead(200);
                res.end(JSON.stringify({
                    success: true,
                    username: username,
                    platform: platform,
                    timestamp: new Date().toISOString(),
                    dataSource: realProfileData ? 'Real API Data' : 'Simulated Data',
                    ...analysisResult
                }));
            } catch (error) {
                console.error('Analysis error:', error);
                res.writeHead(500);
                res.end(JSON.stringify({
                    error: 'Analysis failed',
                    message: 'An error occurred while analyzing the account'
                }));
            }
        });
        return;
    }

    // 404
    res.writeHead(404);
    res.end(JSON.stringify({
        error: 'Not found',
        message: 'The requested endpoint does not exist'
    }));
});

server.listen(PORT, () => {
    console.log(`
╔═══════════════════════════════════════════════════════╗
║     Fake Account Detector API Server Started          ║
║  Developed by Sunit Katuwal (BSc CSIT)                ║
╚═══════════════════════════════════════════════════════╝

Server running at: http://localhost:${PORT}
Health check: http://localhost:${PORT}/health

Ready to analyze fake accounts!
    `);
});
