/**
 * Analysis Controller
 * Handles fake account detection logic
 * Developed by Sunit Katuwal (BSc CSIT)
 */

const { analyzeUsername, calculateFollowerRatio, analyzeEngagement, analyzeActivity } = require('../utils/analysis');

exports.analyzeAccount = async (req, res) => {
    try {
        const { username, platform } = req.body;

        if (!username || !platform) {
            return res.status(400).json({
                error: 'Missing required fields',
                message: 'Please provide username and platform'
            });
        }

        // Validate platform
        const validPlatforms = ['instagram', 'tiktok', 'twitter'];
        if (!validPlatforms.includes(platform.toLowerCase())) {
            return res.status(400).json({
                error: 'Invalid platform',
                message: `Platform must be one of: ${validPlatforms.join(', ')}`
            });
        }

        // Validate username
        if (username.length < 2 || username.length > 100) {
            return res.status(400).json({
                error: 'Invalid username',
                message: 'Username must be between 2 and 100 characters'
            });
        }

        // Simulate account analysis
        const analysisResult = performAnalysis(username, platform);

        res.json({
            success: true,
            username: username,
            platform: platform,
            timestamp: new Date().toISOString(),
            ...analysisResult
        });

    } catch (error) {
        console.error('Analysis error:', error);
        res.status(500).json({
            error: 'Analysis failed',
            message: 'An error occurred while analyzing the account'
        });
    }
};

/**
 * Performs comprehensive fake account analysis
 * @param {string} username 
 * @param {string} platform 
 * @returns {Object} Analysis results
 */
function performAnalysis(username, platform) {
    // Generate consistent but realistic mock data
    const seed = hashUsername(username);
    
    // Generate follower/following/posts data
    const { followers, following, posts } = generateUserStats(seed);
    
    // Calculate risk factors
    const usernameRisk = analyzeUsername(username, seed);
    const ratioRisk = calculateFollowerRatio(followers, following, seed);
    const engagementRisk = analyzeEngagement(followers, posts, seed);
    const activityRisk = analyzeActivity(posts, seed);
    
    // Additional metrics
    const engagementRate = generateEngagementRate(seed);
    const activityFrequency = generateActivityFrequency(seed);
    const postConsistency = generatePostConsistency(seed);
    const commentRatio = generateCommentRatio(seed);
    const likeDensity = generateLikeDensity(seed);

    // Calculate weighted fake score
    const scores = [
        { value: usernameRisk, weight: 0.25 },
        { value: ratioRisk, weight: 0.25 },
        { value: engagementRisk, weight: 0.25 },
        { value: activityRisk, weight: 0.25 }
    ];

    const fakeScore = Math.round(
        scores.reduce((sum, score) => sum + (score.value * score.weight), 0)
    );

    // Create factors breakdown
    const factors = [
        {
            name: 'Username Pattern',
            description: usernameRisk > 60 
                ? 'Suspicious characters, numbers, or unusual formatting detected'
                : 'Username appears legitimate',
            risk: usernameRisk,
            icon: usernameRisk > 60 ? '⚠️' : '✓'
        },
        {
            name: 'Follower Ratio',
            description: ratioRisk > 60
                ? `Unusual followers-to-following ratio (${(followers/following).toFixed(2)})`
                : `Normal followers-to-following ratio (${(followers/following).toFixed(2)})`,
            risk: ratioRisk,
            icon: ratioRisk > 60 ? '⚠️' : '✓'
        },
        {
            name: 'Engagement Rate',
            description: engagementRisk > 60
                ? `Low engagement rate (${engagementRate.toFixed(1)}%)`
                : `Healthy engagement rate (${engagementRate.toFixed(1)}%)`,
            risk: engagementRisk,
            icon: engagementRisk > 60 ? '⚠️' : '✓'
        },
        {
            name: 'Activity Pattern',
            description: activityRisk > 60
                ? `Irregular posting pattern detected`
                : `Consistent posting pattern`,
            risk: activityRisk,
            icon: activityRisk > 60 ? '⚠️' : '✓'
        },
        {
            name: 'Account Verification',
            description: platform === 'instagram' && seed % 5 === 0
                ? 'Account is verified'
                : 'Account is not officially verified',
            risk: platform === 'instagram' && seed % 5 === 0 ? 10 : 30,
            icon: platform === 'instagram' && seed % 5 === 0 ? '✓' : '⚠️'
        }
    ];

    return {
        followers,
        following,
        posts,
        fakeScore,
        engagementRate,
        activityFrequency,
        postConsistency,
        commentRatio,
        likeDensity,
        factors
    };
}

/**
 * Simple hash function for consistent results
 */
function hashUsername(username) {
    let hash = 0;
    for (let i = 0; i < username.length; i++) {
        const char = username.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    return Math.abs(hash);
}

/**
 * Generate user statistics (followers, following, posts)
 */
function generateUserStats(seed) {
    // Realistic ranges
    const followers = Math.floor(Math.random() * 450000) + 50;
    const following = Math.floor(Math.random() * 10000) + 50;
    const posts = Math.floor(Math.random() * 1000) + 1;

    return { followers, following, posts };
}

/**
 * Generate engagement rate (0-100)
 */
function generateEngagementRate(seed) {
    return Math.max(0.5, Math.min(15, Math.random() * 12 + (seed % 3)));
}

/**
 * Generate activity frequency (0-100)
 */
function generateActivityFrequency(seed) {
    return Math.max(5, Math.min(95, Math.random() * 80 + (seed % 20)));
}

/**
 * Generate post consistency (0-100)
 */
function generatePostConsistency(seed) {
    return Math.max(0, Math.min(100, Math.random() * 70 + (seed % 30)));
}

/**
 * Generate comment ratio (0-100)
 */
function generateCommentRatio(seed) {
    return Math.max(0, Math.min(100, Math.random() * 50 + (seed % 25)));
}

/**
 * Generate like density (0-100)
 */
function generateLikeDensity(seed) {
    return Math.max(10, Math.min(100, Math.random() * 75 + (seed % 25)));
}
