// ============================================
// 3D Background Setup with Three.js
// ============================================
let scene, camera, renderer;
let particles = [];

function initThreeJSBackground() {
    const container = document.getElementById('background-canvas');
    
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(
        75,
        window.innerWidth / window.innerHeight,
        0.1,
        1000
    );
    camera.position.z = 50;

    renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);

    // Create particles
    const geometry = new THREE.BufferGeometry();
    const positionArray = new Float32Array(1500);

    for (let i = 0; i < 1500; i += 3) {
        positionArray[i] = (Math.random() - 0.5) * 200;
        positionArray[i + 1] = (Math.random() - 0.5) * 200;
        positionArray[i + 2] = (Math.random() - 0.5) * 200;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positionArray, 3));

    const material = new THREE.PointsMaterial({
        size: 0.5,
        color: 0x00d4ff,
        transparent: true,
        opacity: 0.6,
        sizeAttenuation: true
    });

    const particleSystem = new THREE.Points(geometry, material);
    scene.add(particleSystem);

    // Animation loop
    function animate() {
        requestAnimationFrame(animate);

        particleSystem.rotation.x += 0.0001;
        particleSystem.rotation.y += 0.0002;

        // Mouse interaction
        particleSystem.rotation.x += (mouse.y * 0.005 - particleSystem.rotation.x) * 0.05;
        particleSystem.rotation.y += (mouse.x * 0.005 - particleSystem.rotation.y) * 0.05;

        renderer.render(scene, camera);
    }

    animate();

    // Handle window resize
    window.addEventListener('resize', () => {
        const width = window.innerWidth;
        const height = window.innerHeight;
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height);
    });
}

// ============================================
// Mouse Tracking for Cursor Trail
// ============================================
const mouse = { x: 0, y: 0 };
const cursorTrail = document.querySelector('.cursor-trail');
let cursorX = 0, cursorY = 0;

document.addEventListener('mousemove', (e) => {
    mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;

    cursorX = e.clientX - 10;
    cursorY = e.clientY - 10;

    cursorTrail.style.left = cursorX + 'px';
    cursorTrail.style.top = cursorY + 'px';
});

// Hide cursor trail on non-interactive devices
if (!window.matchMedia('(pointer:coarse)').matches) {
    cursorTrail.style.display = 'block';
}

// ============================================
// Sound Effects
// ============================================
const soundContext = new (window.AudioContext || window.webkitAudioContext)();

function playSound(frequency = 800, duration = 100, type = 'sine') {
    const now = soundContext.currentTime;
    const oscillator = soundContext.createOscillator();
    const gainNode = soundContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(soundContext.destination);

    oscillator.frequency.value = frequency;
    oscillator.type = type;

    gainNode.gain.setValueAtTime(0.1, now);
    gainNode.gain.exponentialRampToValueAtTime(0.01, now + duration / 1000);

    oscillator.start(now);
    oscillator.stop(now + duration / 1000);
}

function playButtonClick() {
    playSound(800, 100);
    playSound(1000, 100);
}

function playAnalyzeSound() {
    playSound(600, 200, 'square');
    playSound(900, 200, 'square');
    playSound(1200, 200, 'square');
}

function playSuccessSound() {
    playSound(1200, 100);
    setTimeout(() => playSound(1500, 100), 100);
}

// ============================================
// Theme Toggle
// ============================================
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = document.getElementById('theme-icon');

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    document.body.classList.toggle('light-theme');
    themeIcon.textContent = document.body.classList.contains('dark-theme') ? '🌙' : '☀️';
    playButtonClick();
});

// ============================================
// API Configuration
// ============================================
const API_BASE_URL = 'http://localhost:3000/api';

// ============================================
// Form Handling
// ============================================
const analyzeBtn = document.getElementById('analyze-btn');
const exampleBtn = document.getElementById('example-btn');
const usernameInput = document.getElementById('username-input');
const platformRadios = document.querySelectorAll('input[name="platform"]');
const btnText = document.getElementById('btn-text');
const btnLoader = document.getElementById('btn-loader');

analyzeBtn.addEventListener('click', analyzeAccount);
exampleBtn.addEventListener('click', loadExampleData);

// Platform selector
document.querySelectorAll('.platform-selector').forEach(label => {
    label.addEventListener('click', () => {
        playButtonClick();
    });
});

// Button click sounds
analyzeBtn.addEventListener('mouseenter', () => {
    playButtonClick();
});

// ============================================
// Main Analysis Function
// ============================================
async function analyzeAccount() {
    const username = usernameInput.value.trim();
    const platform = document.querySelector('input[name="platform"]:checked').value;

    if (!username) {
        showError('Please enter a username or profile link');
        return;
    }

    try {
        analyzeBtn.disabled = true;
        btnText.textContent = 'Analyzing';
        btnLoader.classList.remove('hidden');
        showLoadingSkeleton(true);
        playAnalyzeSound();

        const response = await fetch(`${API_BASE_URL}/analyze`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: username,
                platform: platform
            })
        });

        if (!response.ok) {
            throw new Error('Analysis failed');
        }

        const data = await response.json();

        // Show results
        displayResults(data, username, platform);
        playSuccessSound();
        showSuccess('Analysis complete!');

    } catch (error) {
        console.error('Error:', error);
        showError('Failed to analyze account. Please check the backend server.');
    } finally {
        analyzeBtn.disabled = false;
        btnText.textContent = 'Analyze';
        btnLoader.classList.add('hidden');
        showLoadingSkeleton(false);
    }
}

// ============================================
// Results Display
// ============================================
function displayResults(data, username, platform) {
    const resultsSection = document.getElementById('results-section');
    
    // Show data source badge
    const dataSource = data.dataSource || 'Simulated Data';
    const badgeColor = dataSource === 'Real API Data' ? 'from-green-500 to-emerald-500' : 'from-blue-500 to-cyan-500';
    
    // Update profile info
    document.getElementById('profile-name').textContent = '@' + username;
    document.getElementById('profile-platform').textContent = platform.charAt(0).toUpperCase() + platform.slice(1) + ' Profile' + 
        ` <span class="text-xs ml-3 px-2 py-1 rounded-full bg-gradient-to-r ${badgeColor} text-white">📊 ${dataSource}</span>`;
    document.getElementById('profile-followers').textContent = formatNumber(data.followers);
    document.getElementById('profile-following').textContent = formatNumber(data.following);
    document.getElementById('profile-posts').textContent = formatNumber(data.posts);

    // Update fake score with animation
    const fakeScore = data.fakeScore;
    const scoreBar = document.getElementById('score-bar');
    const scorePercentage = document.getElementById('score-percentage');

    // Animate the progress bar
    setTimeout(() => {
        scoreBar.style.width = fakeScore + '%';
    }, 100);

    // Animate the percentage number
    animateCounter(scorePercentage, 0, fakeScore, 1000);

    // Update risk level
    const riskLevel = getRiskLevel(fakeScore);
    document.getElementById('risk-level').innerHTML = `<span class="${getRiskClass(fakeScore)}">${riskLevel}</span>`;

    // Update confidence and data source
    document.getElementById('confidence-score').textContent = (100 - Math.abs(50 - fakeScore) / 0.5).toFixed(0) + '%';
    document.getElementById('data-source').textContent = dataSource.includes('Real') ? '✓ Real Data' : '⚙️ Simulated';

    // Display analysis factors
    displayAnalysisFactors(data.factors);

    // Create charts
    createEngagementChart(data);
    createFactorsChart(data.factors);

    // Show results section with animation
    resultsSection.classList.remove('hidden');
    resultsSection.scrollIntoView({ behavior: 'smooth' });
}

function getRiskLevel(score) {
    if (score < 30) return 'Low';
    if (score < 60) return 'Medium';
    return 'High';
}

function getRiskClass(score) {
    if (score < 30) return 'risk-low';
    if (score < 60) return 'risk-medium';
    return 'risk-high';
}

function displayAnalysisFactors(factors) {
    const container = document.getElementById('analysis-factors');
    container.innerHTML = '';

    factors.forEach((factor, index) => {
        const card = document.createElement('div');
        card.className = 'factor-card animate-slideInUp';
        card.style.animationDelay = (index * 0.1) + 's';
        card.innerHTML = `
            <div class="factor-icon">${factor.icon}</div>
            <div class="factor-content">
                <div class="factor-name">${factor.name}</div>
                <div class="factor-description">${factor.description}</div>
                <div class="factor-meter">
                    <div class="factor-bar" style="width: ${factor.risk}%"></div>
                </div>
            </div>
            <div style="min-width: 60px; text-align: right;">
                <span style="font-weight: bold; color: #00d4ff;">${factor.risk}%</span>
            </div>
        `;
        container.appendChild(card);
    });
}

// ============================================
// Chart.js Integration
// ============================================
let engagementChart = null;
let factorsChart = null;

function createEngagementChart(data) {
    const ctx = document.getElementById('engagement-chart').getContext('2d');
    
    if (engagementChart) {
        engagementChart.destroy();
    }

    engagementChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Engagement Rate', 'Activity Frequency', 'Post Consistency', 'Comment Ratio', 'Like Density'],
            datasets: [{
                label: 'Profile Metrics',
                data: [
                    data.engagementRate,
                    data.activityFrequency,
                    data.postConsistency,
                    data.commentRatio,
                    data.likeDensity
                ],
                borderColor: 'rgba(0, 212, 255, 0.8)',
                backgroundColor: 'rgba(0, 212, 255, 0.2)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(0, 212, 255, 1)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        color: 'rgba(255, 255, 255, 0.8)'
                    }
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.6)'
                    }
                }
            }
        }
    });
}

function createFactorsChart(factors) {
    const ctx = document.getElementById('factors-chart').getContext('2d');
    
    if (factorsChart) {
        factorsChart.destroy();
    }

    factorsChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: factors.map(f => f.name),
            datasets: [{
                data: factors.map(f => f.risk),
                backgroundColor: [
                    'rgba(239, 68, 68, 0.8)',
                    'rgba(245, 158, 11, 0.8)',
                    'rgba(59, 130, 246, 0.8)',
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(168, 85, 247, 0.8)'
                ],
                borderColor: [
                    'rgba(239, 68, 68, 1)',
                    'rgba(245, 158, 11, 1)',
                    'rgba(59, 130, 246, 1)',
                    'rgba(16, 185, 129, 1)',
                    'rgba(168, 85, 247, 1)'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        color: 'rgba(255, 255, 255, 0.8)'
                    }
                }
            }
        }
    });
}

// ============================================
// Example Data Loader
// ============================================
function loadExampleData() {
    playButtonClick();
    
    const exampleData = {
        followers: 1250,
        following: 3400,
        posts: 24,
        fakeScore: 72,
        engagementRate: 2.5,
        activityFrequency: 15,
        postConsistency: 8,
        commentRatio: 3,
        likeDensity: 45,
        factors: [
            {
                name: 'Username Pattern',
                description: 'Suspicious random characters and numbers detected',
                risk: 85,
                icon: '🔤'
            },
            {
                name: 'Follower Ratio',
                description: 'Unusual followers-to-following ratio (0.37)',
                risk: 78,
                icon: '👥'
            },
            {
                name: 'Engagement Rate',
                description: 'Engagement metrics are below average',
                risk: 65,
                icon: '💬'
            },
            {
                name: 'Activity Pattern',
                description: 'Irregular posting and interaction patterns',
                risk: 72,
                icon: '📊'
            },
            {
                name: 'Account Age',
                description: 'Account is relatively new (3 months)',
                risk: 55,
                icon: '⏰'
            }
        ]
    };

    displayResults(exampleData, 'fake_user_123', 'instagram');
    usernameInput.value = 'fake_user_123';
}

// ============================================
// Action Buttons
// ============================================
document.getElementById('analyze-another-btn').addEventListener('click', () => {
    playButtonClick();
    usernameInput.value = '';
    document.getElementById('results-section').classList.add('hidden');
    usernameInput.focus();
});

document.getElementById('download-report-btn').addEventListener('click', () => {
    playButtonClick();
    generateAndDownloadReport();
});

// ============================================
// Notification System
// ============================================
function showError(message) {
    const errorDiv = document.getElementById('error-message');
    const errorText = document.getElementById('error-text');
    
    errorText.textContent = message;
    errorDiv.classList.remove('hidden');

    errorDiv.querySelector('button').addEventListener('click', () => {
        errorDiv.classList.add('hidden');
    });

    setTimeout(() => {
        errorDiv.classList.add('hidden');
    }, 5000);
}

function showSuccess(message) {
    const successDiv = document.getElementById('success-toast');
    const successText = document.getElementById('success-text');
    
    successText.textContent = message;
    successDiv.classList.remove('hidden');

    setTimeout(() => {
        successDiv.classList.add('hidden');
    }, 3000);
}

function showLoadingSkeleton(show) {
    const skeleton = document.getElementById('loading-skeleton');
    if (show) {
        skeleton.classList.remove('hidden');
    } else {
        skeleton.classList.add('hidden');
    }
}

// ============================================
// Utility Functions
// ============================================
function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

function animateCounter(element, start, end, duration) {
    let current = start;
    const increment = end / (duration / 10);
    const timer = setInterval(() => {
        current += increment;
        if (current >= end) {
            current = end;
            clearInterval(timer);
        }
        element.textContent = Math.floor(current) + '%';
    }, 10);
}

function generateAndDownloadReport() {
    const profileName = document.getElementById('profile-name').textContent;
    const fakeScore = document.getElementById('score-percentage').textContent;
    const riskLevel = document.getElementById('risk-level').textContent;

    const reportContent = `
FAKE ACCOUNT DETECTION REPORT
================================================
Generated by FakeDetect
Developed by Sunit Katuwal (BSc CSIT)
================================================

Profile: ${profileName}
Fake Score: ${fakeScore}
Risk Level: ${riskLevel}

Followers: ${document.getElementById('profile-followers').textContent}
Following: ${document.getElementById('profile-following').textContent}
Posts: ${document.getElementById('profile-posts').textContent}

Generated on: ${new Date().toLocaleString()}

================================================
This report is for informational purposes only.
================================================
    `;

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(reportContent));
    element.setAttribute('download', `FakeDetect_Report_${Date.now()}.txt`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

// ============================================
// Initialization
// ============================================
window.addEventListener('load', () => {
    initThreeJSBackground();
});

// Enter key to analyze
usernameInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        analyzeAccount();
    }
});
